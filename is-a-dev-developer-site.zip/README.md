# Developer Lab — Cloudflare Pages

Static, non-commercial personal developer site designed for direct deployment on Cloudflare Pages.

## Deployment

Cloudflare Dashboard → Workers & Pages → Create application → Pages → Direct Upload / Drag and drop.

Upload this ZIP directly. Cloudflare Pages supports a ZIP file for drag-and-drop Direct Upload.

## Site focus

- Software development
- Cloudflare Workers and edge infrastructure
- DNS and HTTP diagnostics
- Client-side developer utilities
- Personal, non-commercial experiments

No server-side runtime, database, login, analytics, advertising, or external build step is required.

## Editing

The whole site is contained in:

- `index.html`
- `style.css`
- `script.js`
- `404.html`
- `_headers`

The JSON formatter runs entirely in the browser; it does not upload the entered data.
