const $ = (selector) => document.querySelector(selector);

$("#year").textContent = new Date().getFullYear();

const input = $("#jsonInput");
const output = $("#jsonOutput");
const status = $("#jsonStatus");

function parseJson() {
  const raw = input.value.trim();
  if (!raw) throw new Error("Input is empty.");
  return JSON.parse(raw);
}

$("#formatBtn").addEventListener("click", () => {
  try {
    const value = parseJson();
    output.textContent = JSON.stringify(value, null, 2);
    status.textContent = "Valid JSON. Formatted successfully.";
    status.dataset.state = "ok";
  } catch (err) {
    output.textContent = "";
    status.textContent = `Invalid JSON: ${err.message}`;
    status.dataset.state = "error";
  }
});

$("#minifyBtn").addEventListener("click", () => {
  try {
    const value = parseJson();
    output.textContent = JSON.stringify(value);
    status.textContent = "Valid JSON. Minified successfully.";
    status.dataset.state = "ok";
  } catch (err) {
    output.textContent = "";
    status.textContent = `Invalid JSON: ${err.message}`;
    status.dataset.state = "error";
  }
});

$("#clearBtn").addEventListener("click", () => {
  input.value = "";
  output.textContent = "";
  status.textContent = "Waiting for input.";
  delete status.dataset.state;
});
